const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 1999,
    image: "https://via.placeholder.com/150?text=Headphones"
  },
  {
    id: 2,
    name: "Smart Watch",
    price: 2999,
    image: "https://via.placeholder.com/150?text=Watch"
  },
  {
    id: 3,
    name: "Bluetooth Speaker",
    price: 1499,
    image: "https://via.placeholder.com/150?text=Speaker"
  },
  {
    id: 4,
    name: "Gaming Mouse",
    price: 799,
    image: "https://via.placeholder.com/150?text=Mouse"
  }
];
export default products;
